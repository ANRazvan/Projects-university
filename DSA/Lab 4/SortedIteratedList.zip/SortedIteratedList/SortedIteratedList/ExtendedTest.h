#pragma once

void testAllExtended();
